<template>
    <select>
<slot></slot>
    </select>
</template>
