export const localhost = 'http://localhost:5000/api';
export const aws = 'http://livingtanakhapplicationde-env.eba-i3mkpska.eu-central-1.elasticbeanstalk.com/api';